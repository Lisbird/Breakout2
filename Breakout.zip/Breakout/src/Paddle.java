public class Paddle extends GameObject{
}
