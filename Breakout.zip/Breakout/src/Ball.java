public class Ball extends GameObject{
}
