import java.awt.Color;
import java.awt.Rectangle;

public class GameObject {
    private int xPosition;
    private int yPosition;
    private int xSize;
    private int ySize;

    GameObject(GameLogic logicInput, int xPosition, int yPosition, int xSize, int ySize, Color color) {

    }

    public void setPosition(int xPosition, int yPosition) {

    }

    public int getXPosition() {
        return xPosition;
    }

    public int getYPosition() {
        return yPosition;
    }

    public int getXSize() {
        return xSize;
    }

    public int getYSize() {
        return ySize;
    }

    public Rectangle getHitBox() {
        Rectangle objectR = new Rectangle(xPosition, yPosition, xSize, ySize);
        return objectR;
    }
}
