public class Brick extends GameObject{
}
